export function getLevelName(level) {
    if (level == 0) return "Easy";
    if (level == 1) return "Basic";
    if (level == 2) return "Advanced";
    if (level == 3) return "Expert";
    if (level == 4) return "Master";
    if (level == 5) return "Re:Master";
    if (level == 6) return "UTAGE/Original";
}