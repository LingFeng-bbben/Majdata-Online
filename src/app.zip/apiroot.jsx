'use client'

export const apiroot1 = 'https://majdata.net/api1/api'
export const apiroot2 = 'https://majdata.net/api2/api'
export const apiroot3 = 'https://majdata.net/api3/api'

// export const apiroot1 = 'http://101.132.193.53:5001/api'
// export const apiroot2 = 'http://101.132.193.53:5002/api'
// export const apiroot3 = 'http://101.132.193.53:5003/api'